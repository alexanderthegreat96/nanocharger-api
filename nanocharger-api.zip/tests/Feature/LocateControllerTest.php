<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class LocateControllerTest extends TestCase
{
    public function didNotWriteTestsForThisDueToTheComplexityOfArrayResponses() {
        return 'Check API Docs';
    }
}
